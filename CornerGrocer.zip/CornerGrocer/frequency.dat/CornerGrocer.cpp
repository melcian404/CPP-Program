/*
CS-210 Corner Grocer
Professor: Cory Thoma
Author: Melissa Cianfarano
Date: 06-16-2023
*/


/*
The goal of this application
is to allow Corner Grocer to tally 
the amount of times their items are
purchased so they can create an 
effective layout for customers.
*/

#include <iostream>
#include <fstream>
#include <map>
#include <sstream>
#include <string>

using namespace std;

// set private and public
class CornerGrocer {
private:
    string item;
    int freq = 0;
    map<string, int> itemQuantity;

public:
    int grocerMenu();
    void openFile();
    int userInput = 0;
};

int CornerGrocer::grocerMenu() {
    // Do-While with nested switch statements until exit is chosen
    do {
        // create user menu prompts
        cout << "=====================================" << endl;
        cout << "|     Welcome To Corner Grocer!     |" << endl;
        cout << "|     1) Search for an item         |" << endl;
        cout << "|     2) Print quantity of item     |" << endl;
        cout << "|     3) Print as a histogram       |" << endl;
        cout << "|     4) Exit                       |" << endl;
        cout << "=====================================" << endl;
        cout << endl;
        cout << "    Enter Choice: ";

        // get user input
        cin >> userInput;

        // switch statements to easily read input
        switch (userInput) {

        //Menu option 1 - search item
        case 1: {
            string itemName;
            cout << "Enter item name: ";
            cin >> itemName;

            if (itemQuantity.count(itemName) > 0) {
                cout << itemName << " " << itemQuantity[itemName] << endl;
            }
            else {
                cout << "No items by that name. Try a different item." << endl;
            }
            break;
        }

        //Menu option 2 - item quantity
        case 2: {
            for (const auto& item : itemQuantity) {
                cout << item.first << " - " << item.second << endl;
            }
            break;
        }

        //Menu option 3 - count with astericks
        case 3: {
            for (const auto& item : itemQuantity) {
                cout << item.first << " ";
                for (int i = 1; i <= item.second; i++) {
                    cout << "*";
                }
                cout << endl;
            }
            break;
        }

        // Menu option 4 - exit
        case 4: {
            cout << "Exit Program" << endl;
            break;
        }

        default: {
            cout << "Invalid choice, enter a new item." << endl;
        }
        }
    } while (userInput != 4);

    //output frequency dat file
    ofstream outFS("frequency.dat");

    // check if frequency dat file opened
    if (!outFS.is_open()) {
        cout << "Unable to open file." << endl;
        return 1;
    }

    for (const auto& item : itemQuantity) {
        outFS << item.first << " - " << item.second << endl;
    }

    // close frequency dat file
    outFS.close();
    return 0;
}

void CornerGrocer::openFile() {
    // read from txt file
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    
    // if else to check if file is open or closed
    if (!inputFile) {
        cout << "Unable to open file." << endl;
        return;
    }
    else {
        cout << "Opened File." << endl;
    }

    string line, word;
    while (getline(inputFile, line)) {
        istringstream iss(line);
        while (iss >> word) {
            itemQuantity[word]++;
        }
    }

    inputFile.close();
}

int main() {
    CornerGrocer i;
    i.openFile();
    i.grocerMenu();

    return 0;
}

